﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Modulos_Generar_Pedido
{
    public partial class Generar_Pedido_Usuario : Form
    {
        private Dictionary<string, (string Nombre, int Puntos)> clientesRegistrados = new Dictionary<string, (string, int)>
        {
            { "1", ("Andrés Heredia", 100) },
            { "2", ("Diego Pérez", 700) },
            { "3", ("Melvin Gutiérrez", 300) },
            { "4", ("Mauricio Valladares", 300) },
            { "5", ("José Castillo", 300) }
        };

        public Generar_Pedido_Usuario()
        {
            InitializeComponent();
        }

        public class Flor
        {
            public string Nombre { get; set; }
            public int Cantidad { get; set; }
            public decimal PrecioUnitario { get; set; }

            public decimal Total => Cantidad * PrecioUnitario;

            public override string ToString()
            {
                return $"{Nombre} - {Cantidad} x {PrecioUnitario:C2} = {Total:C2}";
            }
        }

        private void Generar_Pedido_Presencial_Load(object sender, EventArgs e)
        {
            listView_carritoCompra.View = View.Details;
            listView_carritoCompra.Columns.Add("Flor", 100);
            listView_carritoCompra.Columns.Add("Cantidad", 70);
            listView_carritoCompra.Columns.Add("Precio Unitario", 100);
            listView_carritoCompra.Columns.Add("Total", 100);

            textBox_nombreCliente.KeyPress += textBox_nombreCliente_KeyPress;
            textBox_apellidoCliente.KeyPress += textBox_apellidoCliente_KeyPress;
            textBox_telefono.KeyPress += textBox_telefono_KeyPress;

            dateTimePicker_fecha.MinDate = DateTime.Today;
            dateTimePicker_hora.Format = DateTimePickerFormat.Time;
            dateTimePicker_hora.ShowUpDown = true;
            dateTimePicker_hora.MinDate = DateTime.Today.AddHours(8);
            dateTimePicker_hora.MaxDate = DateTime.Today.AddHours(20);
            dateTimePicker_hora.ValueChanged += dateTimePicker_hora_ValueChanged;

            radioButton_pedidoDomicilio.Enabled = true;
            radioButton_pedidoDomicilio.Checked = false;
            textBox_domicilio.Enabled = false;
            radioButton_pagoPuntos.Enabled = false;

            comboBox_flores.Items.AddRange(new string[] { "Rosas", "Tulipanes", "Girasoles", "Lirios", "Orquídeas", "Arreglo de cumpleaños", "Arreglo para eventos", "Arreglo para bodas"});

        }

        private void AgregarCargoPorEnvio()
        {
            foreach (ListViewItem item in listView_carritoCompra.Items)
            {
                if (item.Text == "Cargo por envio")
                    return;
            }

            decimal precioEnvio = ObtenerPrecioFlor("Cargo por envio");

            // Agregar el cargo por envío al ListView
            ListViewItem cargoEnvio = new ListViewItem("Cargo por envio");
            cargoEnvio.SubItems.Add("1");
            cargoEnvio.SubItems.Add(precioEnvio.ToString("F2"));
            cargoEnvio.SubItems.Add(precioEnvio.ToString("F2"));

            listView_carritoCompra.Items.Add(cargoEnvio);
        }


        private void button_anadirCarrito_Click(object sender, EventArgs e)
        {
            if (comboBox_flores.SelectedItem == null)
            {
                MessageBox.Show("Por favor, selecciona una flor.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string nombreFlor = comboBox_flores.SelectedItem.ToString();
            int cantidad = (int)numericUpDown_flores.Value;
            decimal precioUnitario = ObtenerPrecioFlor(nombreFlor);

            if (cantidad <= 0)
            {
                MessageBox.Show("La cantidad debe ser mayor a 0.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal total = cantidad * precioUnitario;

            ListViewItem item = new ListViewItem(nombreFlor);
            item.SubItems.Add(cantidad.ToString());
            item.SubItems.Add(precioUnitario.ToString("C2"));
            item.SubItems.Add(total.ToString("C2"));

            listView_carritoCompra.Items.Add(item);
        }

        private void button_eliminarProducto_Click(object sender, EventArgs e)
        {
            if (listView_carritoCompra.SelectedItems.Count > 0)
            {
                listView_carritoCompra.Items.Remove(listView_carritoCompra.SelectedItems[0]);
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un producto para eliminar.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void CalcularTotal()
        {
            decimal subtotal = 0;
            decimal IVA = 0.16m;
            decimal impuestosAdicionales = 0.05m;

            foreach (ListViewItem item in listView_carritoCompra.Items)
            {
                decimal totalItem = decimal.Parse(item.SubItems[3].Text, System.Globalization.NumberStyles.Currency);
                subtotal += totalItem;
            }

            decimal totalConImpuestos = subtotal + (subtotal * IVA) + (subtotal * impuestosAdicionales);
            textBox_pagoTotal.Text = totalConImpuestos.ToString("C2");

            MessageBox.Show($"Total con IVA e impuestos: {totalConImpuestos:C2}", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private decimal ObtenerPrecioFlor(string nombreFlor)
        {
            var precios = new Dictionary<string, decimal>
            {
                { "Rosas", 2.50m },
                { "Tulipanes", 3.00m },
                { "Girasoles", 1.75m },
                { "Lirios", 4.00m },
                { "Orquídeas", 5.00m },
                { "Arreglo de cumpleaños", 1400.00m },
                { "Arreglo para eventos", 1900.00m},
                { "Arreglo para bodas", 1600.00m},
                { "Cargo por envio", 10.00m},
            };

            return precios.ContainsKey(nombreFlor) ? precios[nombreFlor] : 0;
        }

        private bool domicilioMarcado = false;
        private void radioButton_pedidoDomicilio_Click(object sender, EventArgs e)
        {
            domicilioMarcado = !domicilioMarcado;
            radioButton_pedidoDomicilio.Checked = domicilioMarcado;
        }

        private void radioButton_pedidoDomicilio_CheckedChanged(object sender, EventArgs e)
        {
            textBox_domicilio.Enabled = radioButton_pedidoDomicilio.Checked;

            if (radioButton_pedidoDomicilio.Checked)
            {
                AgregarCargoPorEnvio();
            }
            else
            {
                foreach (ListViewItem item in listView_carritoCompra.Items)
                {
                    if (item.Text == "Cargo por envio")
                    {
                        listView_carritoCompra.Items.Remove(item);
                        break;
                    }
                }
                textBox_domicilio.Clear();
            }
        }

        private void textBox_id_TextChanged(object sender, EventArgs e)
        {
            string idCliente = textBox_id.Text.Trim();

            if (!string.IsNullOrWhiteSpace(idCliente) && clientesRegistrados.ContainsKey(idCliente))
            {
                radioButton_pagoPuntos.Enabled = true;
            }
            else
            {
                radioButton_pagoPuntos.Enabled = false;
            }
        }

        private bool ValidarClienteEnSistema(string idCliente)
        {
            return clientesRegistrados.ContainsKey(idCliente);
        }

        private int ObtenerPuntosCliente(string idCliente)
        {
            if (clientesRegistrados.TryGetValue(idCliente, out var cliente))
            {
                return cliente.Puntos;
            }
            return 0;
        }

        private void button_confirmarCliente_Click(object sender, EventArgs e)
        {
            string idCliente = textBox_id.Text.Trim();
            string nombre = textBox_nombreCliente.Text.Trim();
            string apellido = textBox_apellidoCliente.Text.Trim();
            string telefono = textBox_telefono.Text.Trim();
            string domicilio = textBox_domicilio.Text.Trim();
            bool domicilioSeleccionado = radioButton_pedidoDomicilio.Checked;

            if (string.IsNullOrWhiteSpace(nombre) || !EsTextoValido(nombre))
            {
                MessageBox.Show("Por favor, ingresa un nombre válido (solo letras).", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(apellido) || !EsTextoValido(apellido))
            {
                MessageBox.Show("Por favor, ingresa un apellido válido (solo letras).", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(telefono) || !EsTelefonoValido(telefono))
            {
                MessageBox.Show("Por favor, ingresa un número de teléfono válido (7 a 10 dígitos).", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (radioButton_pedidoDomicilio.Checked && string.IsNullOrWhiteSpace(domicilio) && !EsDomicilioValido(domicilio))
            {
                MessageBox.Show("Por favor, ingresa un domicilio válido. Se permiten letras, números y los caracteres: , . # -",
                                "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox_domicilio.Focus();
                return;
            }

            bool clienteRegistrado = false;
            string nombreClienteRegistrado = "";
            int puntosCliente = 0;

            if (!string.IsNullOrWhiteSpace(idCliente))
            {
                if (clientesRegistrados.ContainsKey(idCliente))
                {
                    clienteRegistrado = true;
                    (nombreClienteRegistrado, puntosCliente) = clientesRegistrados[idCliente];

                    radioButton_pagoPuntos.Enabled = true;
                }
                else
                {
                    MessageBox.Show("El ID ingresado no está registrado en el sistema.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else
            {
                radioButton_pagoPuntos.Enabled = false;
            }

            string mensaje = $"Datos confirmados:\nNombre: {nombre} {apellido}\nTeléfono: {telefono}";

            if (clienteRegistrado)
            {
                mensaje += $"\nID Cliente: {idCliente} ({nombreClienteRegistrado})\nPuntos acumulados: {puntosCliente}";
            }

            if (domicilioSeleccionado && !string.IsNullOrWhiteSpace(domicilio))
            {
                mensaje += $"\nEntrega a domicilio: Sí\nDirección: {domicilio}";
            }
            else if (domicilioSeleccionado)
            {
                mensaje += "\nEntrega a domicilio: Sí (sin dirección especificada)";
            }
            else
            {
                mensaje += "\nEntrega a domicilio: No";
            }

            MessageBox.Show(mensaje, "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private bool EsTextoValido(string texto)
        {
            return texto.All(char.IsLetter);
        }

        private bool EsTelefonoValido(string telefono)
        {
            return telefono.All(char.IsDigit) && (telefono.Length >= 7 && telefono.Length <= 10);
        }

        private bool EsDomicilioValido(string domicilio)
        {
            string patron = @"^[A-Za-z0-9\s\.,#\-]+$";
            return Regex.IsMatch(domicilio, patron);
        }

        private void textBox_nombreCliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox_apellidoCliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox_telefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox_domicilioCliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetterOrDigit(e.KeyChar) &&
                !char.IsWhiteSpace(e.KeyChar) &&
                e.KeyChar != ',' &&
                e.KeyChar != '.' &&
                e.KeyChar != '#' &&
                e.KeyChar != '-' &&
                !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private bool FechaHoraConfirmadas = false;

        private void button_confirmarFecha_Click(object sender, EventArgs e)
        {
            DateTime fechaSeleccionada = dateTimePicker_fecha.Value.Date;
            DateTime horaSeleccionada = dateTimePicker_hora.Value;

            if (fechaSeleccionada.DayOfWeek == DayOfWeek.Saturday || fechaSeleccionada.DayOfWeek == DayOfWeek.Sunday)
            {
                MessageBox.Show("La fecha seleccionada no es válida. Solo se atiende de lunes a viernes.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (horaSeleccionada.Hour < 8 || horaSeleccionada.Hour >= 20)
            {
                MessageBox.Show("La hora seleccionada no es válida. El horario de atención es de 8:00 AM a 8:00 PM.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show($"Fecha y hora de entrega confirmadas:\n{fechaSeleccionada.ToShortDateString()} a las {horaSeleccionada.ToShortTimeString()}", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dateTimePicker_hora_ValueChanged(object sender, EventArgs e)
        {
            DateTime horaSeleccionada = dateTimePicker_hora.Value;

            if (horaSeleccionada.Hour < 8)
            {
                dateTimePicker_hora.Value = new DateTime(horaSeleccionada.Year, horaSeleccionada.Month, horaSeleccionada.Day, 8, 0, 0);
            }
            else if (horaSeleccionada.Hour >= 20)
            {
                dateTimePicker_hora.Value = new DateTime(horaSeleccionada.Year, horaSeleccionada.Month, horaSeleccionada.Day, 19, 59, 0);
            }
        }

        private void button_confirmarFormaPago_Click(object sender, EventArgs e)
        {
            decimal totalPedido;

            if (!decimal.TryParse(textBox_pagoTotal.Text, System.Globalization.NumberStyles.Currency, null, out totalPedido) || totalPedido <= 0)
            {
                MessageBox.Show("Por favor, genera el total del pedido antes de confirmar la forma de pago.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (radioButton_pagoEfectivo.Checked)
            {
                MessageBox.Show("Forma de pago confirmada: Efectivo", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else if (radioButton_pagoTarjeta.Checked)
            {
                MessageBox.Show("Forma de pago confirmada: Tarjeta. El pago se realizará mediante la terminal en tienda.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else if (radioButton_pagoPuntos.Checked)
            {
                string idCliente = textBox_id.Text.Trim();

                if (clientesRegistrados.ContainsKey(idCliente))
                {
                    int puntosCliente = clientesRegistrados[idCliente].Puntos;

                    if (puntosCliente >= totalPedido)
                    {
                        MessageBox.Show($"Se realizo el canjeo de puntos.\nTotal descontado: {totalPedido} puntos.\nPuntos restantes: {puntosCliente - (int)totalPedido}", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                    }
                    else
                    {
                        MessageBox.Show("No hay suficientes puntos para realizar esta compra.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("El cliente no está registrado, no puede pagar con puntos.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else if (radioButton_pagoTransferencia.Checked)
            {
                MessageBox.Show("Forma de pago confirmada: Transferencia Bancaria.\n" +
                        "Por favor, realiza la transferencia a la siguiente cuenta:\n\n" +
                        "Banco: Banco Ejemplo\n" +
                        "Cuenta: 1234567890\n" +
                        "CLABE: 012345678901234567\n" +
                        "Titular: Floralia\n\n" +
                        "Incluye el número de pedido como referencia.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Por favor, selecciona una forma de pago antes de continuar.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button_confirmarPedido_Click(object sender, EventArgs e)
        {
            if (listView_carritoCompra.Items.Count == 0)
            {
                MessageBox.Show("El carrito de compra está vacío. Agrega al menos una flor para continuar.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string idCliente = textBox_id.Text.Trim();
            string nombre = textBox_nombreCliente.Text.Trim();
            string apellido = textBox_apellidoCliente.Text.Trim();
            string telefono = textBox_telefono.Text.Trim();
            string domicilio = textBox_domicilio.Text.Trim();

            if (string.IsNullOrWhiteSpace(nombre) || !EsTextoValido(nombre))
            {
                MessageBox.Show("Por favor, ingresa un nombre válido (solo letras).", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(apellido) || !EsTextoValido(apellido))
            {
                MessageBox.Show("Por favor, ingresa un apellido válido (solo letras).", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(telefono) || !EsTelefonoValido(telefono))
            {
                MessageBox.Show("Por favor, ingresa un número de teléfono válido (7 a 10 dígitos).", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (radioButton_pedidoDomicilio.Checked && string.IsNullOrWhiteSpace(domicilio))
            {
                MessageBox.Show("Por favor, ingresa un domicilio válido. Se permiten letras, números y los caracteres: , . # -", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool esClienteRegistrado = false;
            int puntosCliente = 0;

            if (!string.IsNullOrWhiteSpace(idCliente))
            {
                esClienteRegistrado = ValidarClienteEnSistema(idCliente);
                puntosCliente = ObtenerPuntosCliente(idCliente);

                if (!esClienteRegistrado)
                {
                    MessageBox.Show("El ID de cliente ingresado no existe en el sistema.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            DateTime fechaSeleccionada = dateTimePicker_fecha.Value.Date;
            DateTime horaSeleccionada = dateTimePicker_hora.Value;

            if (fechaSeleccionada.DayOfWeek == DayOfWeek.Saturday || fechaSeleccionada.DayOfWeek == DayOfWeek.Sunday)
            {
                MessageBox.Show("La fecha seleccionada no es válida. Solo se atiende de lunes a viernes.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (horaSeleccionada.Hour < 8 || horaSeleccionada.Hour >= 20)
            {
                MessageBox.Show("La hora seleccionada no es válida. El horario de atención es de 8:00 AM a 8:00 PM.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!radioButton_pagoEfectivo.Checked && !radioButton_pagoTarjeta.Checked && !radioButton_pagoTransferencia.Checked && !radioButton_pagoPuntos.Checked)
            {
                MessageBox.Show("Por favor, selecciona una forma de pago antes de continuar.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal totalPedido = decimal.Parse(textBox_pagoTotal.Text, System.Globalization.NumberStyles.Currency);

            if (radioButton_pagoPuntos.Checked)
            {
                if (!esClienteRegistrado)
                {
                    MessageBox.Show("Solo los clientes registrados pueden pagar con puntos.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (puntosCliente < totalPedido)
                {
                    MessageBox.Show($"No hay suficientes puntos. Puntos disponibles: {puntosCliente}, Total del pedido: {totalPedido}.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            if (radioButton_pedidoDomicilio.Checked && string.IsNullOrWhiteSpace(domicilio))
            {
                MessageBox.Show("Por favor, ingresa una dirección para el pedido a domicilio.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox_pagoTotal.Text) || textBox_pagoTotal.Text == "$0.00")
            {
                MessageBox.Show("Por favor, genera el total del pedido antes de confirmar.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirmacion = MessageBox.Show("¿Estás seguro de que quieres confirmar este pedido?", "Floralia", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmacion == DialogResult.Yes)
            {
                string formaPago = radioButton_pagoEfectivo.Checked ? "Efectivo" :
                                   radioButton_pagoTarjeta.Checked ? "Tarjeta" :
                                   radioButton_pagoTransferencia.Checked ? "Transferencia" : "Puntos";

                string mensajeTicket = $"Pedido confirmado exitosamente.\n\n" +
                                       $"🔹 Cliente: {nombre} {apellido}\n" +
                                       $"🔹 Teléfono: {telefono}\n" +
                                       (esClienteRegistrado ? $"🔹 ID Cliente: {idCliente}\n🔹 Puntos disponibles antes del pago: {puntosCliente}\n" : "") +
                                       $"🔹 Entrega: {fechaSeleccionada.ToShortDateString()} a las {horaSeleccionada.ToShortTimeString()}\n" +
                                       (radioButton_pedidoDomicilio.Checked ? $"🔹 Domicilio: {domicilio}\n" : "") +
                                       $"🔹 Forma de pago: {formaPago}\n" +
                                       $"🔹 Total: {totalPedido:C2}";

                if (radioButton_pagoPuntos.Checked && esClienteRegistrado)
                {
                    int puntosRestantes = puntosCliente - (int)totalPedido;
                    mensajeTicket += $"\n🔹 Puntos restantes después del pago: {puntosRestantes}";
                }

                MessageBox.Show(mensajeTicket, "Floralia - Ticket de Pago", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            LimpiarCampos();
        }

        private void button_cancelarPedido_Click_1(object sender, EventArgs e)
        {
            DialogResult confirmacion = MessageBox.Show("¿Estás seguro de que quieres cancelar el pedido?", "Floralia - Cancelar Pedido", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmacion == DialogResult.Yes)
            {
                LimpiarCampos();
                MessageBox.Show("El pedido ha sido cancelado y todos los campos fueron limpiados.", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void LimpiarCampos()
        {
            listView_carritoCompra.Items.Clear();
            radioButton_pedidoDomicilio.Checked = false;
            textBox_id.Clear();
            textBox_nombreCliente.Clear();
            textBox_apellidoCliente.Clear();
            textBox_telefono.Clear();
            textBox_domicilio.Clear();
            dateTimePicker_fecha.Value = DateTime.Today;
            dateTimePicker_hora.Value = DateTime.Today.AddHours(8);
            radioButton_pagoEfectivo.Checked = false;
            radioButton_pagoTarjeta.Checked = false;
            radioButton_pagoTransferencia.Checked = false;
            radioButton_pagoPuntos.Checked = false;
            textBox_pagoTotal.Text = "$0.00";
            comboBox_flores.SelectedIndex = -1;
            numericUpDown_flores.Value = 1;
        }

        private void button_generarTotal_Click(object sender, EventArgs e)
        {
            decimal subtotal = 0;
            decimal IVA = 0.16m;
            decimal impuestosAdicionales = 0.05m;

            foreach (ListViewItem item in listView_carritoCompra.Items)
            {
                decimal totalItem = decimal.Parse(item.SubItems[3].Text, System.Globalization.NumberStyles.Currency);
                subtotal += totalItem;
            }

            decimal totalConImpuestos = subtotal + (subtotal * IVA) + (subtotal * impuestosAdicionales);
            textBox_pagoTotal.Text = totalConImpuestos.ToString("C2");

            MessageBox.Show($"El total con IVA e impuestos es: {totalConImpuestos:C2}", "Floralia", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

