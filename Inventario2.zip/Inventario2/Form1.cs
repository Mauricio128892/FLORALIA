﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventario2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CargarFlores();
        }

        private void CargarFlores()
        {
            // Lista de flores
            string[] flores = { "Rosa", "Tulipán", "Margarita", "Girasol", "Lirio", "Orquídea" };

            // Poblar el ComboBox
            comboBoxFlores.Items.AddRange(flores);
        }
        private void SeleccionarImagen()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Archivos de imagen (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBoxImagen.ImageLocation = openFileDialog.FileName;
            }
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            // Validar si se ha seleccionado una imagen
            if (string.IsNullOrEmpty(pictureBoxImagen.ImageLocation))
            {
                MessageBox.Show("Es necesario escoger una foto para agregarlo a la tabla.");
                return;
            }

            // Validar que la cantidad sea un número válido
            if (!int.TryParse(textBoxCantidad.Text, out int cantidad))
            {
                MessageBox.Show("La cantidad debe ser un número válido.");
                return;
            }

            // Validar que el precio sea un número vál ido
            if (!decimal.TryParse(textBoxPrecio.Text, out decimal precio))
            {
                MessageBox.Show("El precio debe ser un número válido.");
                return;
            }

            // Agregar la información a la tabla
            dataGridViewInventario.Rows.Add(
                comboBoxFlores.SelectedItem, // Nombre de la flor
                cantidad,                    // Cantidad
                precio,                      // Precio
                Image.FromFile(pictureBoxImagen.ImageLocation) // Cargar la imagen
            );

            // Limpiar los campos después de agregar
            comboBoxFlores.SelectedIndex = -1; // Limpiar la selección del ComboBox
            textBoxCantidad.Clear();           // Limpiar el TextBox de cantidad
            textBoxPrecio.Clear();             // Limpiar el TextBox de precio
            pictureBoxImagen.Image = null;     // Limpiar la imagen del PictureBox
        }

        private void buttonBorrar_Click(object sender, EventArgs e)
        {
            if (dataGridViewInventario.SelectedRows.Count > 0)
            {
                dataGridViewInventario.Rows.RemoveAt(dataGridViewInventario.SelectedRows[0].Index);
            }
            else
            {
                MessageBox.Show("Por favor, selecciona una fila para borrar.");
            }
        }

        private void buttonCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
         
        }

        private void pictureBoxImagen_Click(object sender, EventArgs e)
        {

        }

        private void buttonSeleccionarImagen_Click(object sender, EventArgs e)
        {
            // Crear un cuadro de diálogo para seleccionar archivos
            OpenFileDialog openFileDialog = new OpenFileDialog();

            // Configurar el filtro para mostrar solo imágenes
            openFileDialog.Filter = "Archivos de imagen (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";

            // Mostrar el cuadro de diálogo
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Cargar la imagen seleccionada en el PictureBox
                pictureBoxImagen.ImageLocation = openFileDialog.FileName;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewInventario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
